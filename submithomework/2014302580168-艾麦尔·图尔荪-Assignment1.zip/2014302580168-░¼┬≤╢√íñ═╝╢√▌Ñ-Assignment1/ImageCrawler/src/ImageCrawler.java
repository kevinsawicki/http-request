

import java.io.File;


import com.github.kevinsawicki.http.HttpRequest;

public class ImageCrawler {

	public ImageCrawler() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String url="http://210.42.121.241/stu/stu_index.jsp";//��ַ
		File input = new File("F:/workspace/ImageCrawler/1FBQGD1W.txt");//cookie�ļ���ַ
		int response = HttpRequest.post(url).send(input).code();//����cookie
	    File output = new File("F:/workspace/ImageCrawler/output/test.html");//��������ļ�
		HttpRequest.get(url).receive(output);  //���
	}

}
